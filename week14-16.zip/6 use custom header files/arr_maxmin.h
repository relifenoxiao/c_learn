int find_max(int* arr, int n);
int find_min(int* arr, int n);
