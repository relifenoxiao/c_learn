#pragma once
int* prime_arr(int low, int up);
